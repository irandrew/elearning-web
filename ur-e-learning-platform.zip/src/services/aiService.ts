import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function askAssistant(question: string, lessonContent: string, history: { role: 'user' | 'model', text: string }[]) {
  const model = "gemini-3-flash-preview";
  
  const systemInstruction = `
    You are an AI Study Assistant for the University of Rwanda (UR). 
    Help students understand the lesson content provided. 
    Keep your explanations clear, academic, and encouraging. 
    Use local context (Rwanda, UR) when relevant.
    Lesson Content:
    ${lessonContent}
  `;

  const chat = ai.chats.create({
    model,
    config: {
      systemInstruction,
    },
    history: history.map(h => ({
      role: h.role,
      parts: [{ text: h.text }]
    }))
  });

  const response = await chat.sendMessage({
    message: question
  });

  return response.text;
}
