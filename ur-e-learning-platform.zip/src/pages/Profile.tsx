import { useAuth } from '../contexts/AuthContext';
import { User, Mail, ShieldCheck, Calendar, GraduationCap, School } from 'lucide-react';
import { motion } from 'motion/react';

export default function Profile() {
  const { user, profile } = useAuth();

  if (!user || !profile) return null;

  const stats = [
    { label: 'Role', value: profile.role === 'lecturer' ? 'Lecturer' : 'Student', icon: profile.role === 'lecturer' ? School : GraduationCap },
    { label: 'Status', value: 'Active', icon: ShieldCheck },
    { label: 'Joined', value: profile.createdAt ? new Date(profile.createdAt).toLocaleDateString() : 'Today', icon: Calendar },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white rounded-[2.5rem] p-8 md:p-12 border border-gray-100 shadow-sm relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-50 rounded-full translate-x-1/2 -translate-y-1/2 -z-10" />
        
        <div className="flex flex-col md:flex-row items-center md:items-start gap-8">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-32 h-32 md:w-40 md:h-40 rounded-[2rem] border-4 border-white shadow-lg overflow-hidden shrink-0"
          >
            <img 
              src={user.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.uid}`} 
              alt={user.displayName || 'Profile'} 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </motion.div>
          
          <div className="flex-1 text-center md:text-left space-y-4">
            <div>
              <h1 className="text-3xl md:text-5xl font-black text-gray-900 leading-tight">
                {user.displayName}
              </h1>
              <div className="flex items-center justify-center md:justify-start space-x-2 text-gray-500 mt-2">
                <Mail className="w-4 h-4" />
                <span className="text-sm font-medium">{user.email}</span>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 pt-4">
              {stats.map((stat, i) => (
                <div key={i} className="bg-gray-50 px-6 py-3 rounded-2xl border border-gray-100 flex items-center space-x-3">
                  <stat.icon className="w-5 h-5 text-[#004A99]" />
                  <div>
                    <p className="text-[10px] uppercase font-bold text-gray-400 tracking-wider leading-none mb-1">{stat.label}</p>
                    <p className="text-sm font-bold text-gray-900 leading-none">{stat.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white rounded-[2rem] p-8 border border-gray-100 shadow-sm space-y-6">
          <h2 className="text-xl font-bold text-gray-900 border-b border-gray-50 pb-4">Account Security</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl">
              <div className="flex items-center space-x-3">
                <ShieldCheck className="w-5 h-5 text-green-500" />
                <span className="text-sm font-medium">Verified Email</span>
              </div>
              <span className="text-xs font-bold text-green-600 bg-green-100 px-2 py-1 rounded-full uppercase tracking-tighter">Verified</span>
            </div>
            <p className="text-xs text-gray-400 px-2">Your account is secured via University Google Auth.</p>
          </div>
        </div>

        <div className="bg-[#004A99] rounded-[2rem] p-8 text-white relative overflow-hidden group">
          <div className="relative z-10 space-y-6">
            <h2 className="text-xl font-bold">University Resources</h2>
            <div className="space-y-3">
              {['Digital Library', 'Student Portal', 'Exam Portal', 'Research Hub'].map((link) => (
                <a 
                  key={link} 
                  href="#" 
                  className="flex items-center justify-between p-4 bg-white/10 hover:bg-white/20 rounded-2xl transition-all group"
                >
                  <span className="text-sm font-medium">{link}</span>
                  <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center group-hover:bg-white group-hover:text-[#004A99] transition-all">
                    <User className="w-4 h-4" />
                  </div>
                </a>
              ))}
            </div>
          </div>
          <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-2xl pointer-events-none group-hover:scale-110 transition-transform" />
        </div>
      </div>
    </div>
  );
}
