import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { db } from '../lib/firebase';
import { doc, getDoc, addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { useAuth } from '../contexts/AuthContext';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ClipboardCheck, 
  FileText, 
  Clock, 
  ChevronRight, 
  ChevronLeft, 
  Send, 
  CheckCircle2, 
  AlertCircle,
  Trophy,
  Loader2
} from 'lucide-react';
import { cn } from '../lib/utils';
import { Assessment, Question } from '../types';

export default function AssessmentView() {
  const { courseId, assessmentId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [assessment, setAssessment] = useState<Assessment | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitted, setSubmitted] = useState(false);
  
  // Quiz State
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [timeLeft, setTimeLeft] = useState<number | null>(null);
  const timerRef = useRef<any>(null);

  // Assignment State
  const [submissionText, setSubmissionText] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!assessmentId || !courseId) return;

    const fetchAssessment = async () => {
      try {
        const docSnap = await getDoc(doc(db, `courses/${courseId}/assessments`, assessmentId));
        if (docSnap.exists()) {
          const data = docSnap.data() as Assessment;
          setAssessment({ id: docSnap.id, ...data });
          if (data.type === 'quiz' && data.timeLimit) {
            setTimeLeft(data.timeLimit * 60);
          }
        }
      } catch (err) {
        console.error("Fetch assessment error:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchAssessment();
  }, [assessmentId, courseId]);

  useEffect(() => {
    if (timeLeft !== null && timeLeft > 0 && !submitted) {
      timerRef.current = setInterval(() => {
        setTimeLeft(prev => {
          if (prev && prev > 0) return prev - 1;
          if (prev === 0) {
            clearInterval(timerRef.current);
            handleSubmit();
            return 0;
          }
          return prev;
        });
      }, 1000);
    }
    return () => clearInterval(timerRef.current);
  }, [timeLeft, submitted]);

  const handleAnswerSelect = (questionId: string, answer: any) => {
    setAnswers(prev => ({ ...prev, [questionId]: answer }));
  };

  const handleSubmit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!user || !assessment || submitting) return;

    setSubmitting(true);
    try {
      const submissionData = {
        userId: user.uid,
        userName: user.displayName || 'Anonymous',
        courseId,
        lecturerId: assessment.courseId === courseId ? (await getDoc(doc(db, 'courses', courseId!))).data()?.lecturerId : null,
        artifactId: assessmentId,
        type: assessment.type,
        content: assessment.type === 'quiz' ? answers : { text: submissionText },
        submittedAt: serverTimestamp(),
      };

      await addDoc(collection(db, 'submissions'), submissionData);
      setSubmitted(true);
      clearInterval(timerRef.current);
    } catch (err) {
      console.error("Submission error:", err);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <div className="flex items-center justify-center py-20"><Loader2 className="w-10 h-10 animate-spin text-gray-300" /></div>;
  if (!assessment) return <div className="text-center py-20">Assessment not found.</div>;

  if (submitted) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-2xl mx-auto py-20 text-center space-y-8"
      >
        <div className="w-24 h-24 bg-green-50 rounded-[2rem] flex items-center justify-center mx-auto text-green-500 mb-8 border border-green-100 ring-8 ring-green-50/50">
          <Trophy className="w-12 h-12" />
        </div>
        <div>
          <h1 className="text-4xl font-black text-gray-900 mb-2 tracking-tight">Submission Completed!</h1>
          <p className="text-gray-500">Your work has been submitted successfully to your lecturer.</p>
        </div>
        <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm inline-block">
          <div className="flex items-center space-x-3 text-sm font-bold text-gray-700">
            <CheckCircle2 className="w-5 h-5 text-green-500" />
            <span>Identity Verified</span>
            <span className="w-1.5 h-1.5 rounded-full bg-gray-200" />
            <span className="text-gray-400">Timestamp: {new Date().toLocaleTimeString()}</span>
          </div>
        </div>
        <div className="pt-8">
          <button
            onClick={() => navigate(`/course/${courseId}`)}
            className="bg-[#004A99] text-white px-10 py-4 rounded-2xl font-bold hover:bg-blue-800 transition-all shadow-lg"
          >
            Return to Syllabus
          </button>
        </div>
      </motion.div>
    );
  }

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2 relative z-10">
          <div className="flex items-center space-x-2">
            <div className={cn(
              "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest",
              assessment.type === 'quiz' ? "bg-purple-100 text-purple-600" : "bg-orange-100 text-orange-600"
            )}>
              {assessment.type}
            </div>
            {timeLeft !== null && (
              <div className="flex items-center space-x-2 bg-red-50 text-red-600 px-3 py-1 rounded-full text-xs font-bold ring-4 ring-red-50/50">
                <Clock className="w-3 h-3" />
                <span>{formatTime(timeLeft)}</span>
              </div>
            )}
          </div>
          <h1 className="text-3xl font-black text-gray-900 tracking-tight">{assessment.title}</h1>
          <p className="text-gray-500 text-sm max-w-lg">{assessment.description}</p>
        </div>

        <div className="shrink-0 relative z-10">
          {assessment.type === 'quiz' && (
            <div className="bg-gray-50 p-4 rounded-2xl border border-gray-100 text-center">
              <p className="text-[10px] uppercase font-black text-gray-400 tracking-widest mb-1">Progress</p>
              <p className="text-2xl font-black text-[#004A99]">
                {Object.keys(answers).length} / {assessment.questions?.length}
              </p>
            </div>
          )}
        </div>
      </div>

      {assessment.type === 'quiz' ? (
        <div className="space-y-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentQuestionIndex}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="bg-white p-10 rounded-[2.5rem] border border-gray-100 shadow-sm space-y-8"
            >
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gray-50 border border-gray-100 rounded-2xl flex items-center justify-center font-black text-gray-400">
                  {currentQuestionIndex + 1}
                </div>
                <h2 className="text-2xl font-bold text-gray-900 leading-snug">
                  {assessment.questions![currentQuestionIndex].text}
                </h2>
              </div>

              <div className="space-y-4">
                {assessment.questions![currentQuestionIndex].type === 'multiple-choice' && (
                  assessment.questions![currentQuestionIndex].options?.map((opt, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleAnswerSelect(assessment.questions![currentQuestionIndex].id, opt)}
                      className={cn(
                        "w-full text-left p-6 rounded-2xl border-2 transition-all flex items-center justify-between group",
                        answers[assessment.questions![currentQuestionIndex].id] === opt
                          ? "border-[#004A99] bg-blue-50 text-[#004A99]"
                          : "border-gray-50 hover:border-gray-200 text-gray-600"
                      )}
                    >
                      <span className="font-medium">{opt}</span>
                      <div className={cn(
                        "w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all",
                        answers[assessment.questions![currentQuestionIndex].id] === opt
                          ? "border-[#004A99] bg-[#004A99]"
                          : "border-gray-200 group-hover:border-gray-300"
                      )}>
                        {answers[assessment.questions![currentQuestionIndex].id] === opt && <div className="w-2 h-2 bg-white rounded-full" />}
                      </div>
                    </button>
                  ))
                )}

                {assessment.questions![currentQuestionIndex].type !== 'multiple-choice' && (
                   <textarea
                    rows={6}
                    value={answers[assessment.questions![currentQuestionIndex].id] || ''}
                    onChange={(e) => handleAnswerSelect(assessment.questions![currentQuestionIndex].id, e.target.value)}
                    placeholder="Type your answer here..."
                    className="w-full bg-gray-50 border border-gray-100 rounded-3xl p-6 text-sm focus:outline-none focus:ring-2 focus:ring-[#004A99]/10 focus:border-[#004A99] transition-all resize-none"
                  />
                )}
              </div>
            </motion.div>
          </AnimatePresence>

          <div className="flex items-center justify-between pt-4">
            <button
              onClick={() => setCurrentQuestionIndex(prev => Math.max(0, prev - 1))}
              disabled={currentQuestionIndex === 0}
              className="flex items-center space-x-2 px-8 py-4 rounded-2xl font-bold text-gray-500 hover:bg-white transition-all disabled:opacity-0"
            >
              <ChevronLeft className="w-5 h-5" />
              <span>Previous</span>
            </button>

            {currentQuestionIndex === assessment.questions!.length - 1 ? (
              <button
                onClick={() => handleSubmit()}
                disabled={submitting}
                className="flex items-center space-x-2 px-10 py-5 bg-[#004A99] text-white rounded-[2rem] font-bold hover:bg-blue-800 transition-all shadow-xl"
              >
                {submitting ? <Loader2 className="w-6 h-6 animate-spin" /> : <Send className="w-5 h-5" />}
                <span>Final Submission</span>
              </button>
            ) : (
              <button
                onClick={() => setCurrentQuestionIndex(prev => Math.min(assessment.questions!.length - 1, prev + 1))}
                className="flex items-center space-x-2 px-10 py-5 bg-white text-[#004A99] border border-gray-100 rounded-[2rem] font-bold hover:bg-gray-50 transition-all shadow-sm"
              >
                <span>Next Question</span>
                <ChevronRight className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="space-y-8">
          <div className="bg-white p-10 rounded-[2.5rem] border border-gray-100 shadow-sm space-y-8">
            <div className="flex items-center space-x-4 mb-4">
              <div className="w-10 h-10 bg-orange-50 text-orange-600 rounded-xl flex items-center justify-center">
                <FileText className="w-5 h-5" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">Your Submission</h3>
            </div>

            <div className="p-6 bg-orange-50/50 rounded-2xl border border-orange-100 mb-8">
              <h4 className="text-[10px] uppercase font-black text-orange-400 tracking-widest flex items-center gap-1 mb-2">
                <AlertCircle className="w-3 h-3" />
                Grading Criteria
              </h4>
              <p className="text-orange-900 text-sm">{assessment.gradingCriteria}</p>
            </div>

            <textarea
              rows={12}
              value={submissionText}
              onChange={(e) => setSubmissionText(e.target.value)}
              placeholder="Paste your essay or project links here..."
              className="w-full bg-gray-50 border border-gray-100 rounded-3xl p-8 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/10 focus:border-orange-500 transition-all resize-none"
            />
          </div>

          <div className="flex justify-end">
             <button
              onClick={() => handleSubmit()}
              disabled={!submissionText.trim() || submitting}
              className="flex items-center space-x-3 px-12 py-5 bg-orange-600 text-white rounded-[2rem] font-bold hover:bg-orange-700 transition-all shadow-xl disabled:opacity-50 disabled:grayscale"
            >
              {submitting ? <Loader2 className="w-6 h-6 animate-spin" /> : <Send className="w-5 h-5" />}
              <span>Turn In Assignment</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
