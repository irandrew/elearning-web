/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Dashboard from './pages/Dashboard';
import CourseDetails from './pages/CourseDetails';
import LessonView from './pages/LessonView';
import Profile from './pages/Profile';
import AssessmentView from './pages/AssessmentView';
import GraderView from './pages/GraderView';
import RoleSelection from './components/RoleSelection';
import { motion } from 'motion/react';

function AppContent() {
  const { user, profile, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-[#f5f5f5]">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-12 h-12 border-4 border-[#004A99] border-t-transparent rounded-full"
        />
        <p className="mt-4 text-[#004A99] font-medium animate-pulse">Loading UR E-Learning...</p>
      </div>
    );
  }

  // If logged in but no role, force role selection
  if (user && profile && !profile.role) {
    return <RoleSelection />;
  }

  return (
    <div className="min-h-screen bg-[#f5f5f5] text-[#1a1a1a] font-sans">
      <Navbar />
      <main className="max-w-7xl mx-auto px-4 py-8">
        <Routes location={location} key={location.pathname}>
          <Route path="/" element={<Home />} />
          <Route path="/dashboard" element={user ? <Dashboard /> : <Navigate to="/" />} />
          <Route path="/profile" element={user ? <Profile /> : <Navigate to="/" />} />
          <Route path="/course/:courseId" element={<CourseDetails />} />
          <Route path="/course/:courseId/lesson/:lessonId" element={user ? <LessonView /> : <Navigate to="/" />} />
          <Route path="/course/:courseId/assessment/:assessmentId" element={user ? <AssessmentView /> : <Navigate to="/" />} />
          <Route path="/course/:courseId/submissions" element={(profile?.role === 'lecturer' || profile?.role === 'admin') ? <GraderView /> : <Navigate to="/" />} />
        </Routes>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <AppContent />
      </Router>
    </AuthProvider>
  );
}

